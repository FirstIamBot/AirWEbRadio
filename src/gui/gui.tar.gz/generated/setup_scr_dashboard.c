/*
* Copyright 2024 NXP
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "widgets_init.h"
#include "custom.h"



int dashboard_digital_clock_1_min_value = 25;
int dashboard_digital_clock_1_hour_value = 11;
int dashboard_digital_clock_1_sec_value = 50;
char dashboard_digital_clock_1_meridiem[] = "AM";
void setup_scr_dashboard(lv_ui *ui)
{
	//Write codes dashboard
	ui->dashboard = lv_obj_create(NULL);
	lv_obj_set_size(ui->dashboard, 320, 240);
	lv_obj_set_scrollbar_mode(ui->dashboard, LV_SCROLLBAR_MODE_OFF);

	//Write style for dashboard, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->dashboard, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->dashboard, lv_color_hex(0x3d516b), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_grad_dir(ui->dashboard, LV_GRAD_DIR_HOR, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_grad_color(ui->dashboard, lv_color_hex(0x3d516b), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_main_stop(ui->dashboard, 107, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_grad_stop(ui->dashboard, 245, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes dashboard_menu_1
	ui->dashboard_menu_1 = lv_menu_create(ui->dashboard);

	//Create sidebar page for menu dashboard_menu_1
	ui->dashboard_menu_1_sidebar_page = lv_menu_page_create(ui->dashboard_menu_1, "Menu");
	lv_menu_set_sidebar_page(ui->dashboard_menu_1, ui->dashboard_menu_1_sidebar_page);

	//Create subpage for dashboard_menu_1
	ui->dashboard_menu_1_subpage_1 = lv_menu_page_create(ui->dashboard_menu_1, NULL);
	ui->dashboard_menu_1_cont_1 = lv_menu_cont_create(ui->dashboard_menu_1_sidebar_page);
	ui->dashboard_menu_1_label_1 = lv_label_create(ui->dashboard_menu_1_cont_1);
	lv_label_set_text(ui->dashboard_menu_1_label_1, "Air");
	lv_obj_set_size(ui->dashboard_menu_1_label_1, LV_PCT(100), LV_SIZE_CONTENT);
	lv_menu_set_load_page_event(ui->dashboard_menu_1, ui->dashboard_menu_1_cont_1, ui->dashboard_menu_1_subpage_1);

	//Create subpage for dashboard_menu_1
	ui->dashboard_menu_1_subpage_2 = lv_menu_page_create(ui->dashboard_menu_1, NULL);
	ui->dashboard_menu_1_cont_2 = lv_menu_cont_create(ui->dashboard_menu_1_sidebar_page);
	ui->dashboard_menu_1_label_2 = lv_label_create(ui->dashboard_menu_1_cont_2);
	lv_label_set_text(ui->dashboard_menu_1_label_2, "Web");
	lv_obj_set_size(ui->dashboard_menu_1_label_2, LV_PCT(100), LV_SIZE_CONTENT);
	lv_menu_set_load_page_event(ui->dashboard_menu_1, ui->dashboard_menu_1_cont_2, ui->dashboard_menu_1_subpage_2);

	//Create subpage for dashboard_menu_1
	ui->dashboard_menu_1_subpage_3 = lv_menu_page_create(ui->dashboard_menu_1, NULL);
	ui->dashboard_menu_1_cont_3 = lv_menu_cont_create(ui->dashboard_menu_1_sidebar_page);
	ui->dashboard_menu_1_label_3 = lv_label_create(ui->dashboard_menu_1_cont_3);
	lv_label_set_text(ui->dashboard_menu_1_label_3, "Setting");
	lv_obj_set_size(ui->dashboard_menu_1_label_3, LV_PCT(100), LV_SIZE_CONTENT);
	lv_menu_set_load_page_event(ui->dashboard_menu_1, ui->dashboard_menu_1_cont_3, ui->dashboard_menu_1_subpage_3);
	lv_event_send(ui->dashboard_menu_1_cont_1, LV_EVENT_CLICKED, NULL);
	lv_obj_set_pos(ui->dashboard_menu_1, 0, 0);
	lv_obj_set_size(ui->dashboard_menu_1, 320, 240);
	lv_obj_set_scrollbar_mode(ui->dashboard_menu_1, LV_SCROLLBAR_MODE_OFF);

	//Write style for dashboard_menu_1, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->dashboard_menu_1, 195, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->dashboard_menu_1, lv_color_hex(0xb4b4b4), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_grad_dir(ui->dashboard_menu_1, LV_GRAD_DIR_HOR, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_grad_color(ui->dashboard_menu_1, lv_color_hex(0x020202), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_main_stop(ui->dashboard_menu_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_grad_stop(ui->dashboard_menu_1, 129, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->dashboard_menu_1, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->dashboard_menu_1, 179, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->dashboard_menu_1, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->dashboard_menu_1, LV_BORDER_SIDE_FULL, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->dashboard_menu_1, 10, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->dashboard_menu_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_dashboard_menu_1_extra_sidebar_page_main_default
	static lv_style_t style_dashboard_menu_1_extra_sidebar_page_main_default;
	ui_init_style(&style_dashboard_menu_1_extra_sidebar_page_main_default);
	
	lv_style_set_bg_opa(&style_dashboard_menu_1_extra_sidebar_page_main_default, 255);
	lv_style_set_bg_color(&style_dashboard_menu_1_extra_sidebar_page_main_default, lv_color_hex(0xf2f2f2));
	lv_style_set_bg_grad_dir(&style_dashboard_menu_1_extra_sidebar_page_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_radius(&style_dashboard_menu_1_extra_sidebar_page_main_default, 0);
	lv_obj_add_style(ui->dashboard_menu_1_sidebar_page, &style_dashboard_menu_1_extra_sidebar_page_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_dashboard_menu_1_extra_option_btns_main_default
	static lv_style_t style_dashboard_menu_1_extra_option_btns_main_default;
	ui_init_style(&style_dashboard_menu_1_extra_option_btns_main_default);
	
	lv_style_set_text_color(&style_dashboard_menu_1_extra_option_btns_main_default, lv_color_hex(0x000000));
	lv_style_set_text_font(&style_dashboard_menu_1_extra_option_btns_main_default, &lv_font_Alatsi_Regular_18);
	lv_style_set_text_opa(&style_dashboard_menu_1_extra_option_btns_main_default, 255);
	lv_style_set_text_align(&style_dashboard_menu_1_extra_option_btns_main_default, LV_TEXT_ALIGN_CENTER);
	lv_style_set_pad_top(&style_dashboard_menu_1_extra_option_btns_main_default, 6);
	lv_style_set_pad_bottom(&style_dashboard_menu_1_extra_option_btns_main_default, 7);
	lv_obj_add_style(ui->dashboard_menu_1_cont_3, &style_dashboard_menu_1_extra_option_btns_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_add_style(ui->dashboard_menu_1_cont_2, &style_dashboard_menu_1_extra_option_btns_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_add_style(ui->dashboard_menu_1_cont_1, &style_dashboard_menu_1_extra_option_btns_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_CHECKED for &style_dashboard_menu_1_extra_option_btns_main_checked
	static lv_style_t style_dashboard_menu_1_extra_option_btns_main_checked;
	ui_init_style(&style_dashboard_menu_1_extra_option_btns_main_checked);
	
	lv_style_set_text_color(&style_dashboard_menu_1_extra_option_btns_main_checked, lv_color_hex(0x000000));
	lv_style_set_text_font(&style_dashboard_menu_1_extra_option_btns_main_checked, &lv_font_Alatsi_Regular_20);
	lv_style_set_text_opa(&style_dashboard_menu_1_extra_option_btns_main_checked, 255);
	lv_style_set_text_align(&style_dashboard_menu_1_extra_option_btns_main_checked, LV_TEXT_ALIGN_CENTER);
	lv_style_set_border_width(&style_dashboard_menu_1_extra_option_btns_main_checked, 2);
	lv_style_set_border_opa(&style_dashboard_menu_1_extra_option_btns_main_checked, 255);
	lv_style_set_border_color(&style_dashboard_menu_1_extra_option_btns_main_checked, lv_color_hex(0x000000));
	lv_style_set_border_side(&style_dashboard_menu_1_extra_option_btns_main_checked, LV_BORDER_SIDE_BOTTOM);
	lv_style_set_radius(&style_dashboard_menu_1_extra_option_btns_main_checked, 2);
	lv_style_set_bg_opa(&style_dashboard_menu_1_extra_option_btns_main_checked, 255);
	lv_style_set_bg_color(&style_dashboard_menu_1_extra_option_btns_main_checked, lv_color_hex(0xd2d2d2));
	lv_style_set_bg_grad_dir(&style_dashboard_menu_1_extra_option_btns_main_checked, LV_GRAD_DIR_HOR);
	lv_style_set_bg_grad_color(&style_dashboard_menu_1_extra_option_btns_main_checked, lv_color_hex(0xffffff));
	lv_style_set_bg_main_stop(&style_dashboard_menu_1_extra_option_btns_main_checked, 0);
	lv_style_set_bg_grad_stop(&style_dashboard_menu_1_extra_option_btns_main_checked, 0);
	lv_obj_add_style(ui->dashboard_menu_1_cont_3, &style_dashboard_menu_1_extra_option_btns_main_checked, LV_PART_MAIN|LV_STATE_CHECKED);
	lv_obj_add_style(ui->dashboard_menu_1_cont_2, &style_dashboard_menu_1_extra_option_btns_main_checked, LV_PART_MAIN|LV_STATE_CHECKED);
	lv_obj_add_style(ui->dashboard_menu_1_cont_1, &style_dashboard_menu_1_extra_option_btns_main_checked, LV_PART_MAIN|LV_STATE_CHECKED);

	//Write style state: LV_STATE_DEFAULT for &style_dashboard_menu_1_extra_main_title_main_default
	static lv_style_t style_dashboard_menu_1_extra_main_title_main_default;
	ui_init_style(&style_dashboard_menu_1_extra_main_title_main_default);
	
	lv_style_set_text_color(&style_dashboard_menu_1_extra_main_title_main_default, lv_color_hex(0x3f4657));
	lv_style_set_text_font(&style_dashboard_menu_1_extra_main_title_main_default, &lv_font_Alatsi_Regular_25);
	lv_style_set_text_opa(&style_dashboard_menu_1_extra_main_title_main_default, 255);
	lv_style_set_text_align(&style_dashboard_menu_1_extra_main_title_main_default, LV_TEXT_ALIGN_CENTER);
	lv_style_set_bg_opa(&style_dashboard_menu_1_extra_main_title_main_default, 255);
	lv_style_set_bg_color(&style_dashboard_menu_1_extra_main_title_main_default, lv_color_hex(0xd0d0d0));
	lv_style_set_bg_grad_dir(&style_dashboard_menu_1_extra_main_title_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_pad_top(&style_dashboard_menu_1_extra_main_title_main_default, 7);
	lv_style_set_pad_bottom(&style_dashboard_menu_1_extra_main_title_main_default, 7);
	lv_menu_t * dashboard_menu_1_menu= (lv_menu_t *)ui->dashboard_menu_1;
	lv_obj_t * dashboard_menu_1_title = dashboard_menu_1_menu->sidebar_header_title;
	lv_obj_set_size(dashboard_menu_1_title, LV_PCT(100), LV_SIZE_CONTENT);
	lv_obj_add_style(lv_menu_get_sidebar_header(ui->dashboard_menu_1), &style_dashboard_menu_1_extra_main_title_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);



	//Write codes dashboard_spangroup_1
	ui->dashboard_spangroup_1 = lv_spangroup_create(ui->dashboard_menu_1_subpage_1);
	lv_spangroup_set_align(ui->dashboard_spangroup_1, LV_TEXT_ALIGN_LEFT);
	lv_spangroup_set_overflow(ui->dashboard_spangroup_1, LV_SPAN_OVERFLOW_CLIP);
	lv_spangroup_set_mode(ui->dashboard_spangroup_1, LV_SPAN_MODE_FIXED);
	//create spans
	lv_span_t *dashboard_spangroup_1_span;
	dashboard_spangroup_1_span = lv_spangroup_new_span(ui->dashboard_spangroup_1);
	lv_span_set_text(dashboard_spangroup_1_span, "106.1");
	lv_style_set_text_color(&dashboard_spangroup_1_span->style, lv_color_hex(0xfeecec));
	lv_style_set_text_decor(&dashboard_spangroup_1_span->style, LV_TEXT_DECOR_NONE);
	lv_style_set_text_font(&dashboard_spangroup_1_span->style, &lv_font_montserratMedium_30);
	dashboard_spangroup_1_span = lv_spangroup_new_span(ui->dashboard_spangroup_1);
	lv_span_set_text(dashboard_spangroup_1_span, "MHz    ");
	lv_style_set_text_color(&dashboard_spangroup_1_span->style, lv_color_hex(0xccd0d6));
	lv_style_set_text_decor(&dashboard_spangroup_1_span->style, LV_TEXT_DECOR_NONE);
	lv_style_set_text_font(&dashboard_spangroup_1_span->style, &lv_font_montserratMedium_12);
	lv_obj_set_pos(ui->dashboard_spangroup_1, 105, 69);
	lv_obj_set_size(ui->dashboard_spangroup_1, 112, 61);

	//Write style state: LV_STATE_DEFAULT for &style_dashboard_spangroup_1_main_main_default
	static lv_style_t style_dashboard_spangroup_1_main_main_default;
	ui_init_style(&style_dashboard_spangroup_1_main_main_default);
	
	lv_style_set_border_width(&style_dashboard_spangroup_1_main_main_default, 0);
	lv_style_set_radius(&style_dashboard_spangroup_1_main_main_default, 0);
	lv_style_set_bg_opa(&style_dashboard_spangroup_1_main_main_default, 0);
	lv_style_set_pad_top(&style_dashboard_spangroup_1_main_main_default, 6);
	lv_style_set_pad_right(&style_dashboard_spangroup_1_main_main_default, 0);
	lv_style_set_pad_bottom(&style_dashboard_spangroup_1_main_main_default, 0);
	lv_style_set_pad_left(&style_dashboard_spangroup_1_main_main_default, 0);
	lv_style_set_shadow_width(&style_dashboard_spangroup_1_main_main_default, 0);
	lv_obj_add_style(ui->dashboard_spangroup_1, &style_dashboard_spangroup_1_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_spangroup_refr_mode(ui->dashboard_spangroup_1);

	//Write codes dashboard_radio_RDS
	ui->dashboard_radio_RDS = lv_label_create(ui->dashboard_menu_1_subpage_1);
	lv_label_set_text(ui->dashboard_radio_RDS, "HipPop Music Radio");
	lv_label_set_long_mode(ui->dashboard_radio_RDS, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->dashboard_radio_RDS, 3, 175);
	lv_obj_set_size(ui->dashboard_radio_RDS, 200, 20);

	//Write style for dashboard_radio_RDS, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->dashboard_radio_RDS, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->dashboard_radio_RDS, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->dashboard_radio_RDS, lv_color_hex(0xc5e2f2), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->dashboard_radio_RDS, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_opa(ui->dashboard_radio_RDS, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->dashboard_radio_RDS, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->dashboard_radio_RDS, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->dashboard_radio_RDS, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->dashboard_radio_RDS, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->dashboard_radio_RDS, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->dashboard_radio_RDS, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->dashboard_radio_RDS, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->dashboard_radio_RDS, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->dashboard_radio_RDS, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes dashboard_slider_1
	ui->dashboard_slider_1 = lv_slider_create(ui->dashboard_menu_1_subpage_1);
	lv_slider_set_range(ui->dashboard_slider_1, 64, 108);
	lv_slider_set_mode(ui->dashboard_slider_1, LV_SLIDER_MODE_NORMAL);
	lv_slider_set_value(ui->dashboard_slider_1, 90, LV_ANIM_OFF);
	lv_obj_set_pos(ui->dashboard_slider_1, 8, 126);
	lv_obj_set_size(ui->dashboard_slider_1, 205, 62);

	//Write style for dashboard_slider_1, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->dashboard_slider_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->dashboard_slider_1, 50, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_outline_width(ui->dashboard_slider_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_img_src(ui->dashboard_slider_1, &_menu_radio_205x62, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_img_opa(ui->dashboard_slider_1, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->dashboard_slider_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for dashboard_slider_1, Part: LV_PART_INDICATOR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->dashboard_slider_1, 0, LV_PART_INDICATOR|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->dashboard_slider_1, 50, LV_PART_INDICATOR|LV_STATE_DEFAULT);

	//Write style for dashboard_slider_1, Part: LV_PART_KNOB, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->dashboard_slider_1, 0, LV_PART_KNOB|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_img_src(ui->dashboard_slider_1, &_play_72x72, LV_PART_KNOB|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_img_opa(ui->dashboard_slider_1, 255, LV_PART_KNOB|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->dashboard_slider_1, 50, LV_PART_KNOB|LV_STATE_DEFAULT);

	//Write codes dashboard_btnm_1
	ui->dashboard_btnm_1 = lv_btnmatrix_create(ui->dashboard_menu_1_subpage_1);
	static const char *dashboard_btnm_1_text_map[] = {"FM", "MW", "LW", "\n", "SW", "SSB", "AM", "",};
	lv_btnmatrix_set_map(ui->dashboard_btnm_1, dashboard_btnm_1_text_map);
	lv_obj_set_pos(ui->dashboard_btnm_1, 7, 143);
	lv_obj_set_size(ui->dashboard_btnm_1, 207, 81);

	//Write style for dashboard_btnm_1, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->dashboard_btnm_1, 1, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->dashboard_btnm_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->dashboard_btnm_1, lv_color_hex(0xc9c9c9), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->dashboard_btnm_1, LV_BORDER_SIDE_FULL, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->dashboard_btnm_1, 1, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->dashboard_btnm_1, 1, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->dashboard_btnm_1, 1, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->dashboard_btnm_1, 1, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_column(ui->dashboard_btnm_1, 1, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->dashboard_btnm_1, 4, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->dashboard_btnm_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for dashboard_btnm_1, Part: LV_PART_ITEMS, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->dashboard_btnm_1, 1, LV_PART_ITEMS|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->dashboard_btnm_1, 255, LV_PART_ITEMS|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->dashboard_btnm_1, lv_color_hex(0xc9c9c9), LV_PART_ITEMS|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->dashboard_btnm_1, LV_BORDER_SIDE_FULL, LV_PART_ITEMS|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->dashboard_btnm_1, lv_color_hex(0xffffff), LV_PART_ITEMS|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->dashboard_btnm_1, &lv_font_montserratMedium_16, LV_PART_ITEMS|LV_STATE_DEFAULT);
	lv_obj_set_style_text_opa(ui->dashboard_btnm_1, 255, LV_PART_ITEMS|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->dashboard_btnm_1, 4, LV_PART_ITEMS|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->dashboard_btnm_1, 255, LV_PART_ITEMS|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->dashboard_btnm_1, lv_color_hex(0x2195f6), LV_PART_ITEMS|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_grad_dir(ui->dashboard_btnm_1, LV_GRAD_DIR_NONE, LV_PART_ITEMS|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->dashboard_btnm_1, 0, LV_PART_ITEMS|LV_STATE_DEFAULT);



	//Write codes dashboard_label_1
	ui->dashboard_label_1 = lv_label_create(ui->dashboard_menu_1_subpage_2);
	lv_label_set_text(ui->dashboard_label_1, "192.168.0.1");
	lv_label_set_long_mode(ui->dashboard_label_1, LV_LABEL_LONG_WRAP);
	lv_obj_set_pos(ui->dashboard_label_1, 37, 27);
	lv_obj_set_size(ui->dashboard_label_1, 135, 24);

	//Write style for dashboard_label_1, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->dashboard_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->dashboard_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->dashboard_label_1, lv_color_hex(0xe9e3e3), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->dashboard_label_1, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_opa(ui->dashboard_label_1, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->dashboard_label_1, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->dashboard_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->dashboard_label_1, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->dashboard_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->dashboard_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->dashboard_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->dashboard_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->dashboard_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->dashboard_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes dashboard_label_2
	ui->dashboard_label_2 = lv_label_create(ui->dashboard_menu_1_subpage_2);
	lv_label_set_text(ui->dashboard_label_2, "Radio Roks LIVE");
	lv_label_set_long_mode(ui->dashboard_label_2, LV_LABEL_LONG_SCROLL);
	lv_obj_set_pos(ui->dashboard_label_2, 10, 14);
	lv_obj_set_size(ui->dashboard_label_2, 192, 60);

	//Write style for dashboard_label_2, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_border_width(ui->dashboard_label_2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->dashboard_label_2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->dashboard_label_2, lv_color_hex(0xf4eaea), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->dashboard_label_2, &lv_font_montserratMedium_30, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_opa(ui->dashboard_label_2, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->dashboard_label_2, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_line_space(ui->dashboard_label_2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->dashboard_label_2, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->dashboard_label_2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->dashboard_label_2, 23, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->dashboard_label_2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->dashboard_label_2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->dashboard_label_2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->dashboard_label_2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes dashboard_digital_clock_1
	static bool dashboard_digital_clock_1_timer_enabled = false;
	ui->dashboard_digital_clock_1 = lv_dclock_create(ui->dashboard_menu_1_subpage_2, "11:25:50 AM");
	if (!dashboard_digital_clock_1_timer_enabled) {
		lv_timer_create(dashboard_digital_clock_1_timer, 1000, NULL);
		dashboard_digital_clock_1_timer_enabled = true;
	}
	lv_obj_set_pos(ui->dashboard_digital_clock_1, 9, 83);
	lv_obj_set_size(ui->dashboard_digital_clock_1, 203, 48);

	//Write style for dashboard_digital_clock_1, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_radius(ui->dashboard_digital_clock_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->dashboard_digital_clock_1, lv_color_hex(0xd4dde6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->dashboard_digital_clock_1, &lv_font_Alatsi_Regular_25, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_opa(ui->dashboard_digital_clock_1, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->dashboard_digital_clock_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->dashboard_digital_clock_1, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->dashboard_digital_clock_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->dashboard_digital_clock_1, 7, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->dashboard_digital_clock_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->dashboard_digital_clock_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->dashboard_digital_clock_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->dashboard_digital_clock_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);



	//Write codes dashboard_btn_1
	ui->dashboard_btn_1 = lv_btn_create(ui->dashboard_menu_1_subpage_3);
	ui->dashboard_btn_1_label = lv_label_create(ui->dashboard_btn_1);
	lv_label_set_text(ui->dashboard_btn_1_label, "Back");
	lv_label_set_long_mode(ui->dashboard_btn_1_label, LV_LABEL_LONG_WRAP);
	lv_obj_align(ui->dashboard_btn_1_label, LV_ALIGN_CENTER, 0, 0);
	lv_obj_set_style_pad_all(ui->dashboard_btn_1, 0, LV_STATE_DEFAULT);
	lv_obj_set_pos(ui->dashboard_btn_1, 60, 1);
	lv_obj_set_size(ui->dashboard_btn_1, 100, 50);

	//Write style for dashboard_btn_1, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->dashboard_btn_1, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->dashboard_btn_1, lv_color_hex(0x2195f6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_grad_dir(ui->dashboard_btn_1, LV_GRAD_DIR_NONE, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->dashboard_btn_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->dashboard_btn_1, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->dashboard_btn_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->dashboard_btn_1, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->dashboard_btn_1, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_opa(ui->dashboard_btn_1, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_align(ui->dashboard_btn_1, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes dashboard_spinbox_1
	ui->dashboard_spinbox_1 = lv_spinbox_create(ui->dashboard);
	lv_obj_set_pos(ui->dashboard_spinbox_1, 83, 22);
	lv_obj_set_width(ui->dashboard_spinbox_1, 153);
	lv_obj_set_height(ui->dashboard_spinbox_1, 62);
	lv_spinbox_set_digit_format(ui->dashboard_spinbox_1, 4, 3);
	lv_spinbox_set_range(ui->dashboard_spinbox_1, -9999, 9999);
	lv_coord_t dashboard_spinbox_1_h = lv_obj_get_height(ui->dashboard_spinbox_1);
	ui->dashboard_spinbox_1_btn = lv_btn_create(ui->dashboard);
	lv_obj_set_size(ui->dashboard_spinbox_1_btn, dashboard_spinbox_1_h, dashboard_spinbox_1_h);
	lv_obj_align_to(ui->dashboard_spinbox_1_btn, ui->dashboard_spinbox_1, LV_ALIGN_OUT_RIGHT_MID, 5, 0);
	lv_obj_set_style_bg_img_src(ui->dashboard_spinbox_1_btn, LV_SYMBOL_PLUS, 0);
	lv_obj_add_event_cb(ui->dashboard_spinbox_1_btn, lv_dashboard_spinbox_1_increment_event_cb, LV_EVENT_ALL, NULL);
	ui->dashboard_spinbox_1_btn_minus = lv_btn_create(ui->dashboard);
	lv_obj_set_size(ui->dashboard_spinbox_1_btn_minus, dashboard_spinbox_1_h, dashboard_spinbox_1_h);
	lv_obj_align_to(ui->dashboard_spinbox_1_btn_minus, ui->dashboard_spinbox_1, LV_ALIGN_OUT_LEFT_MID, -5, 0);
	lv_obj_set_style_bg_img_src(ui->dashboard_spinbox_1_btn_minus, LV_SYMBOL_MINUS, 0);
	lv_obj_add_event_cb(ui->dashboard_spinbox_1_btn_minus, lv_dashboard_spinbox_1_decrement_event_cb, LV_EVENT_ALL, NULL);
	lv_obj_add_flag(ui->dashboard_spinbox_1, LV_OBJ_FLAG_HIDDEN);
	lv_obj_add_flag(ui->dashboard_spinbox_1_btn, LV_OBJ_FLAG_HIDDEN);lv_obj_add_flag(ui->dashboard_spinbox_1_btn_minus, LV_OBJ_FLAG_HIDDEN);
	lv_obj_set_pos(ui->dashboard_spinbox_1, 83, 22);
	lv_obj_add_flag(ui->dashboard_spinbox_1, LV_OBJ_FLAG_HIDDEN);

	//Write style for dashboard_spinbox_1, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
	lv_obj_set_style_bg_opa(ui->dashboard_spinbox_1, 126, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->dashboard_spinbox_1, lv_color_hex(0xffffff), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_grad_dir(ui->dashboard_spinbox_1, LV_GRAD_DIR_NONE, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_width(ui->dashboard_spinbox_1, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_opa(ui->dashboard_spinbox_1, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_color(ui->dashboard_spinbox_1, lv_color_hex(0x2195f6), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_border_side(ui->dashboard_spinbox_1, LV_BORDER_SIDE_FULL, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_top(ui->dashboard_spinbox_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_right(ui->dashboard_spinbox_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_bottom(ui->dashboard_spinbox_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_pad_left(ui->dashboard_spinbox_1, 10, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_color(ui->dashboard_spinbox_1, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->dashboard_spinbox_1, &lv_font_montserratMedium_31, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_opa(ui->dashboard_spinbox_1, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_text_letter_space(ui->dashboard_spinbox_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_radius(ui->dashboard_spinbox_1, 5, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_set_style_shadow_width(ui->dashboard_spinbox_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style for dashboard_spinbox_1, Part: LV_PART_CURSOR, State: LV_STATE_DEFAULT.
	lv_obj_set_style_text_color(ui->dashboard_spinbox_1, lv_color_hex(0xffffff), LV_PART_CURSOR|LV_STATE_DEFAULT);
	lv_obj_set_style_text_font(ui->dashboard_spinbox_1, &lv_font_montserratMedium_12, LV_PART_CURSOR|LV_STATE_DEFAULT);
	lv_obj_set_style_text_opa(ui->dashboard_spinbox_1, 255, LV_PART_CURSOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_opa(ui->dashboard_spinbox_1, 255, LV_PART_CURSOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_color(ui->dashboard_spinbox_1, lv_color_hex(0x2195f6), LV_PART_CURSOR|LV_STATE_DEFAULT);
	lv_obj_set_style_bg_grad_dir(ui->dashboard_spinbox_1, LV_GRAD_DIR_NONE, LV_PART_CURSOR|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for &style_dashboard_spinbox_1_extra_btns_main_default
	static lv_style_t style_dashboard_spinbox_1_extra_btns_main_default;
	ui_init_style(&style_dashboard_spinbox_1_extra_btns_main_default);
	
	lv_style_set_text_color(&style_dashboard_spinbox_1_extra_btns_main_default, lv_color_hex(0xffffff));
	lv_style_set_text_font(&style_dashboard_spinbox_1_extra_btns_main_default, &lv_font_montserratMedium_12);
	lv_style_set_text_opa(&style_dashboard_spinbox_1_extra_btns_main_default, 255);
	lv_style_set_bg_opa(&style_dashboard_spinbox_1_extra_btns_main_default, 255);
	lv_style_set_bg_color(&style_dashboard_spinbox_1_extra_btns_main_default, lv_color_hex(0x2195f6));
	lv_style_set_bg_grad_dir(&style_dashboard_spinbox_1_extra_btns_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_border_width(&style_dashboard_spinbox_1_extra_btns_main_default, 0);
	lv_style_set_radius(&style_dashboard_spinbox_1_extra_btns_main_default, 5);
	lv_obj_add_style(ui->dashboard_spinbox_1_btn, &style_dashboard_spinbox_1_extra_btns_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_add_style(ui->dashboard_spinbox_1_btn_minus, &style_dashboard_spinbox_1_extra_btns_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//The custom code of dashboard.
	

	//Update current screen layout.
	lv_obj_update_layout(ui->dashboard);

	//Init events for screen.
	events_init_dashboard(ui);
}
